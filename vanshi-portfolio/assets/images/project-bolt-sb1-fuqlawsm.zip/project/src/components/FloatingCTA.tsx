import { useState } from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Calendar } from 'lucide-react';
import { whatsappLink } from '@/lib/whatsapp';

export default function FloatingCTA() {
  const [visible, setVisible] = useState(false);

  if (typeof window !== 'undefined') {
    window.onscroll = () => {
      setVisible(window.scrollY > 600);
    };
  }

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-40 lg:hidden transition-transform duration-400 ${
        visible ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      <div className="grid grid-cols-2 shadow-[0_-4px_20px_rgba(22,36,61,0.12)]">
        <a
          href={whatsappLink()}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 py-4 bg-sage-600 text-white font-medium text-sm"
        >
          <MessageCircle className="w-4 h-4" />
          WhatsApp
        </a>
        <Link
          to="/contact"
          className="flex items-center justify-center gap-2 py-4 bg-navy-900 text-white font-medium text-sm"
        >
          <Calendar className="w-4 h-4" />
          Book Appointment
        </Link>
      </div>
    </div>
  );
}
