import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { X, Calendar, MessageCircle } from 'lucide-react';
import { whatsappLink } from '@/lib/whatsapp';

export default function ExitIntentModal() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    let triggered = false;
    const onMouseLeave = (e: MouseEvent) => {
      if (triggered) return;
      if (e.clientY <= 0) {
        triggered = true;
        setShow(true);
      }
    };
    document.addEventListener('mouseleave', onMouseLeave);
    return () => document.removeEventListener('mouseleave', onMouseLeave);
  }, []);

  if (!show) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-6 animate-fade-in"
      onClick={() => setShow(false)}
    >
      <div className="absolute inset-0 bg-navy-950/50 backdrop-blur-sm" />
      <div
        className="relative bg-ivory-50 rounded-2xl shadow-2xl max-w-md w-full p-8 sm:p-10"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => setShow(false)}
          className="absolute top-4 right-4 p-1.5 text-navy-400 hover:text-navy-900 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
        <div className="text-center">
          <div className="w-14 h-14 rounded-full bg-sage-100 flex items-center justify-center mx-auto mb-5">
            <Calendar className="w-6 h-6 text-sage-600" />
          </div>
          <h3 className="font-serif text-2xl font-semibold text-navy-900 mb-3">
            Thinking about your smile?
          </h3>
          <p className="text-navy-600 text-sm leading-relaxed mb-6">
            Book a no-pressure consultation or send us a quick WhatsApp message — we'll help you understand your options.
          </p>
          <div className="flex flex-col gap-3">
            <Link
              to="/contact"
              onClick={() => setShow(false)}
              className="flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium text-white bg-navy-900 rounded-full hover:bg-sage-600 transition-all duration-300"
            >
              <Calendar className="w-4 h-4" />
              Book a Consultation
            </Link>
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setShow(false)}
              className="flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium text-navy-700 border border-navy-200 rounded-full hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all duration-300"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
