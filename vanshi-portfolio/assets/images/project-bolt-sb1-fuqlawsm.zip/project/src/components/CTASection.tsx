import { Link } from 'react-router-dom';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { whatsappLink } from '@/lib/whatsapp';
import { useReveal } from '@/hooks/useReveal';

interface CTASectionProps {
  title?: string;
  subtitle?: string;
}

export default function CTASection({
  title = 'Ready to feel better about your smile?',
  subtitle = "Start with a simple consultation. Tell us what you'd like to improve and we'll help you understand your options.",
}: CTASectionProps) {
  const { ref, revealed } = useReveal<HTMLDivElement>();

  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div
        ref={ref}
        className={`reveal ${revealed ? 'revealed' : ''} max-w-5xl mx-auto bg-navy-900 rounded-3xl px-6 py-16 sm:px-12 sm:py-20 text-center`}
      >
        <h2 className="font-serif text-heading font-semibold text-white mb-5">
          {title}
        </h2>
        <p className="text-ivory-200/80 text-base sm:text-lg leading-relaxed max-w-xl mx-auto mb-8">
          {subtitle}
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/contact"
            className="flex items-center gap-2 px-7 py-3.5 text-sm font-medium text-navy-900 bg-white rounded-full hover:bg-sage-100 transition-all duration-300 w-full sm:w-auto justify-center"
          >
            Book a Consultation
            <ArrowRight className="w-4 h-4" />
          </Link>
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-7 py-3.5 text-sm font-medium text-white border border-navy-600 rounded-full hover:bg-sage-600 hover:border-sage-600 transition-all duration-300 w-full sm:w-auto justify-center"
          >
            <MessageCircle className="w-4 h-4" />
            WhatsApp Us
          </a>
        </div>
      </div>
    </section>
  );
}
