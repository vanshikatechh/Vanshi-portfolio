import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, MessageCircle, Calendar } from 'lucide-react';
import { clinicConfig } from '@/config/clinic';
import { whatsappLink } from '@/lib/whatsapp';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/treatments', label: 'Treatments' },
  { to: '/before-and-after', label: 'Before & After' },
  { to: '/about', label: 'About' },
  { to: '/patient-experience', label: 'Patient Experience' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-ivory-50/95 backdrop-blur-md shadow-[0_1px_20px_rgba(22,36,61,0.06)]'
            : 'bg-transparent'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-12">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="group flex flex-col leading-none">
              <span className="font-serif text-xl sm:text-2xl font-semibold tracking-wide text-navy-900 transition-colors group-hover:text-sage-600">
                {clinicConfig.name.split(' ')[0]}
              </span>
              <span className="text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-sage-600 font-medium mt-0.5">
                {clinicConfig.name.split(' ').slice(1).join(' ')}
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === '/'}
                  className={({ isActive }) =>
                    `text-sm font-medium tracking-wide transition-colors duration-300 relative after:absolute after:bottom-[-4px] after:left-0 after:h-px after:bg-sage-500 after:transition-all after:duration-300 ${
                      isActive
                        ? 'text-navy-900 after:w-full'
                        : 'text-navy-600 hover:text-navy-900 after:w-0 hover:after:w-full'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
            </div>

            {/* Desktop CTAs */}
            <div className="hidden lg:flex items-center gap-3">
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-navy-700 border border-navy-200 rounded-full hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all duration-300"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp Us
              </a>
              <Link
                to="/contact"
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-navy-900 rounded-full hover:bg-sage-600 transition-all duration-300 shadow-sm"
              >
                <Calendar className="w-4 h-4" />
                Book a Consultation
              </Link>
            </div>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden p-2 text-navy-900"
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile menu overlay */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-400 ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="absolute inset-0 bg-ivory-50" onClick={() => setMenuOpen(false)} />
        <div
          className={`absolute top-20 left-0 right-0 bg-ivory-50 px-6 pb-8 pt-4 transition-transform duration-400 ${
            menuOpen ? 'translate-y-0' : '-translate-y-4'
          }`}
        >
          <div className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/'}
                className={({ isActive }) =>
                  `py-3 text-lg font-medium border-b border-ivory-200 transition-colors ${
                    isActive ? 'text-sage-600' : 'text-navy-700'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </div>
          <div className="flex flex-col gap-3 mt-6">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium text-navy-700 border border-navy-200 rounded-full"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp Us
            </a>
            <Link
              to="/contact"
              className="flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium text-white bg-navy-900 rounded-full"
            >
              <Calendar className="w-4 h-4" />
              Book a Consultation
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
