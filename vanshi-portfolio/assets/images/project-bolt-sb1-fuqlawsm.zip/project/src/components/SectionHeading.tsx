import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
  ctaText?: string;
  ctaTo?: string;
}

export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  center = true,
  ctaText,
  ctaTo,
}: SectionHeadingProps) {
  const { ref, revealed } = useReveal<HTMLDivElement>();

  return (
    <div
      ref={ref}
      className={`reveal ${revealed ? 'revealed' : ''} ${center ? 'text-center mx-auto' : ''} max-w-2xl ${center ? '' : 'max-w-3xl'}`}
    >
      {eyebrow && (
        <p className="text-xs sm:text-sm tracking-[0.2em] uppercase text-sage-600 font-semibold mb-4">
          {eyebrow}
        </p>
      )}
      <h2 className="font-serif text-heading font-semibold text-navy-900 mb-4">
        {title}
      </h2>
      {subtitle && (
        <p className="text-navy-600 text-base sm:text-lg leading-relaxed">
          {subtitle}
        </p>
      )}
      {ctaText && ctaTo && (
        <Link
          to={ctaTo}
          className="inline-flex items-center gap-2 mt-6 text-sm font-semibold text-navy-900 hover:text-sage-600 transition-colors group"
        >
          {ctaText}
          <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
        </Link>
      )}
    </div>
  );
}
