import { Link } from 'react-router-dom';
import { Instagram, MessageCircle, Phone, Mail, MapPin, Clock } from 'lucide-react';
import { clinicConfig } from '@/config/clinic';
import { whatsappLink } from '@/lib/whatsapp';

const footerLinks = [
  { to: '/', label: 'Home' },
  { to: '/treatments', label: 'Treatments' },
  { to: '/before-and-after', label: 'Before & After' },
  { to: '/about', label: 'About' },
  { to: '/patient-experience', label: 'Patient Experience' },
  { to: '/contact', label: 'Contact' },
];

export default function Footer() {
  return (
    <footer className="bg-navy-900 text-ivory-100 pt-20 pb-10 px-5 sm:px-8 lg:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 pb-16 border-b border-navy-700">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex flex-col leading-none mb-4">
              <span className="font-serif text-2xl font-semibold tracking-wide">
                {clinicConfig.name.split(' ')[0]}
              </span>
              <span className="text-[11px] tracking-[0.25em] uppercase text-sage-300 font-medium mt-1">
                {clinicConfig.name.split(' ').slice(1).join(' ')}
              </span>
            </div>
            <p className="text-ivory-200/70 text-sm leading-relaxed max-w-xs">
              {clinicConfig.tagline}
            </p>
            <div className="flex gap-3 mt-6">
              <a
                href={clinicConfig.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-10 h-10 rounded-full border border-navy-600 flex items-center justify-center hover:bg-sage-600 hover:border-sage-600 transition-all duration-300"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="w-10 h-10 rounded-full border border-navy-600 flex items-center justify-center hover:bg-sage-600 hover:border-sage-600 transition-all duration-300"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-xs tracking-[0.2em] uppercase text-sage-300 font-semibold mb-5">
              Explore
            </h3>
            <ul className="space-y-3">
              {footerLinks.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm text-ivory-200/70 hover:text-white transition-colors duration-300"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xs tracking-[0.2em] uppercase text-sage-300 font-semibold mb-5">
              Contact
            </h3>
            <ul className="space-y-4 text-sm text-ivory-200/70">
              <li className="flex items-start gap-3">
                <Phone className="w-4 h-4 mt-0.5 text-sage-300 shrink-0" />
                <a href={clinicConfig.contact.phoneHref} className="hover:text-white transition-colors">
                  {clinicConfig.contact.phone}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="w-4 h-4 mt-0.5 text-sage-300 shrink-0" />
                <a href={`mailto:${clinicConfig.contact.email}`} className="hover:text-white transition-colors">
                  {clinicConfig.contact.email}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 mt-0.5 text-sage-300 shrink-0" />
                <span>
                  {clinicConfig.contact.address.line1}, {clinicConfig.contact.address.line2}
                  <br />
                  {clinicConfig.contact.address.city}, {clinicConfig.contact.address.postcode}
                </span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h3 className="text-xs tracking-[0.2em] uppercase text-sage-300 font-semibold mb-5">
              Opening Hours
            </h3>
            <ul className="space-y-2.5 text-sm text-ivory-200/70">
              {clinicConfig.hours.map((h) => (
                <li key={h.day} className="flex justify-between gap-4">
                  <span>{h.day}</span>
                  <span className={h.time === 'Closed' ? 'text-ivory-200/40' : ''}>{h.time}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-ivory-200/50">
            <span>&copy; {new Date().getFullYear()} {clinicConfig.name}</span>
            <Link to="/privacy" className="hover:text-ivory-200 transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-ivory-200 transition-colors">Terms</Link>
          </div>
          <p className="text-xs text-ivory-200/40 max-w-lg text-center md:text-right leading-relaxed">
            This website is a demonstration concept. Treatment suitability should be assessed by a qualified dental professional.
          </p>
        </div>
      </div>
    </footer>
  );
}
