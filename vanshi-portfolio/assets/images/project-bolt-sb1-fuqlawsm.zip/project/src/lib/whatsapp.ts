import { clinicConfig } from '@/config/clinic';

export function whatsappLink(message?: string) {
  const msg = encodeURIComponent(message ?? clinicConfig.whatsappMessage);
  return `https://wa.me/${clinicConfig.contact.whatsappNumber}?text=${msg}`;
}
