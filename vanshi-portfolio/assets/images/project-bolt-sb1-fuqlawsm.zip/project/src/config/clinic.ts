/**
 * ============================================================================
 *  CLINIC CONFIGURATION — EDIT THIS FILE TO CUSTOMISE FOR ANY DENTAL CLINIC
 * ============================================================================
 *
 *  Every clinic-specific value lives here. Duplicate the project, change the
 *  values below, and the entire website updates automatically — navigation,
 *  headings, buttons, footer, WhatsApp links, contact page, metadata, and
 *  all content.
 *
 *  Fields you should replace:
 *    - name, tagline, shortDescription
 *    - dentist.name, dentist.role, dentist.bio, dentist.philosophy
 *    - contact.phone, contact.whatsapp, contact.email, contact.address
 *    - hours (opening hours)
 *    - social links
 *    - All image URLs (hero, portrait, interiors, treatments, before/after)
 *    - treatments array
 *    - transformations array
 *    - testimonials array
 * ============================================================================
 */

export interface Treatment {
  slug: string;
  name: string;
  category: string;
  shortDescription: string;
  image: string;
  whatItIs: string;
  suitableFor: string;
  consultationProcess: string;
}

export interface Transformation {
  id: string;
  title: string;
  category: string;
  description: string;
  beforeImage: string;
  afterImage: string;
}

export interface Testimonial {
  name: string;
  text: string;
}

export interface ClinicConfig {
  name: string;
  tagline: string;
  shortDescription: string;
  dentist: {
    name: string;
    role: string;
    portrait: string;
    bio: string;
    philosophy: string;
    interests: string[];
  };
  contact: {
    phone: string;
    phoneHref: string;
    whatsapp: string;
    whatsappNumber: string;
    email: string;
    address: {
      line1: string;
      line2: string;
      city: string;
      postcode: string;
    };
    mapsEmbed: string;
    mapsLink: string;
  };
  hours: { day: string; time: string }[];
  social: {
    instagram: string;
    facebook: string;
  };
  images: {
    hero: string;
    heroAlt: string;
    clinicInterior: string[];
    treatmentDefault: string;
  };
  treatments: Treatment[];
  transformations: Transformation[];
  testimonials: Testimonial[];
  whatsappMessage: string;
}

export const clinicConfig: ClinicConfig = {
  // ---- CLINIC IDENTITY ----
  name: 'LUMINA DENTAL STUDIO',
  tagline: 'Modern dentistry. Personalised care.',
  shortDescription:
    'Personalised dental care designed around your comfort, your goals and the smile you want to feel confident sharing.',

  // ---- DENTIST ----
  dentist: {
    name: 'Dr. Aisha Rahman',
    role: 'Principal Dentist & Founder',
    portrait:
      'https://images.pexels.com/photos/37458046/pexels-photo-37458046.jpeg?auto=compress&cs=tinysrgb&w=900',
    bio: 'Dr. Rahman founded Lumina Dental Studio with a clear vision: to create a dental practice where every patient feels heard, comfortable, and genuinely cared for. With years of experience in both cosmetic and restorative dentistry, she takes pride in designing treatment plans that are as individual as the people who walk through the door. Her approach blends modern technique with a calm, unhurried chairside manner — so even the most nervous patients leave smiling.',
    philosophy:
      'I believe great dentistry starts with listening. Before I look at teeth, I want to understand what matters to you — your goals, your concerns, and how you want to feel about your smile. Treatment should never feel rushed or one-size-fits-all.',
    interests: [
      'Cosmetic & smile design',
      'Clear aligner orthodontics',
      'Restorative & implant dentistry',
      'Anxiety-free patient care',
    ],
  },

  // ---- CONTACT ----
  contact: {
    phone: '+44 20 7946 0123',
    phoneHref: 'tel:+442079460123',
    whatsapp: '+44 7700 900123',
    whatsappNumber: '447700900123',
    email: 'hello@luminadental.co.uk',
    address: {
      line1: '112 Harley Street',
      line2: 'Marylebone',
      city: 'London',
      postcode: 'W1G 7JW',
    },
    mapsEmbed:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.9!2d-0.1469!3d51.5194!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTHCsDMxJzA5LjgiTiAwwrA4OCc0MS4wIlc!5e0!3m2!1sen!2suk!4v1700000000000',
    mapsLink: 'https://maps.google.com/?q=112+Harley+Street+London+W1G+7JW',
  },

  // ---- OPENING HOURS ----
  hours: [
    { day: 'Monday', time: '9:00 AM – 6:00 PM' },
    { day: 'Tuesday', time: '9:00 AM – 6:00 PM' },
    { day: 'Wednesday', time: '9:00 AM – 8:00 PM' },
    { day: 'Thursday', time: '9:00 AM – 6:00 PM' },
    { day: 'Friday', time: '9:00 AM – 5:00 PM' },
    { day: 'Saturday', time: '10:00 AM – 2:00 PM' },
    { day: 'Sunday', time: 'Closed' },
  ],

  // ---- SOCIAL ----
  social: {
    instagram: 'https://instagram.com/luminadental',
    facebook: 'https://facebook.com/luminadental',
  },

  // ---- IMAGES ----
  // Replace these URLs with your own clinic photography
  images: {
    hero: 'https://images.pexels.com/photos/16002544/pexels-photo-16002544.jpeg?auto=compress&cs=tinysrgb&w=900',
    heroAlt: 'A woman with a natural, confident smile',
    clinicInterior: [
      'https://images.pexels.com/photos/305567/pexels-photo-305567.jpeg?auto=compress&cs=tinysrgb&w=1200',
      'https://images.pexels.com/photos/4269268/pexels-photo-4269268.jpeg?auto=compress&cs=tinysrgb&w=1200',
      'https://images.pexels.com/photos/6812479/pexels-photo-6812479.jpeg?auto=compress&cs=tinysrgb&w=1200',
      'https://images.pexels.com/photos/17570403/pexels-photo-17570403.jpeg?auto=compress&cs=tinysrgb&w=1200',
    ],
    treatmentDefault:
      'https://images.pexels.com/photos/6812463/pexels-photo-6812463.jpeg?auto=compress&cs=tinysrgb&w=800',
  },

  // ---- TREATMENTS ----
  treatments: [
    {
      slug: 'general-dentistry',
      name: 'General Dentistry',
      category: 'Preventive & Restorative',
      shortDescription: 'Preventive and restorative dental care.',
      image:
        'https://images.pexels.com/photos/5622270/pexels-photo-5622270.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'General dentistry covers the foundation of your oral health — routine check-ups, professional cleaning, fillings, and preventive care. These are the appointments that keep your teeth and gums healthy for the long term, and help catch small issues before they become bigger ones.',
      suitableFor:
        'Everyone. Whether you are due for a routine check-up, have a specific concern, or haven\'t been to a dentist in a while, general dentistry is where comfortable, ongoing care begins.',
      consultationProcess:
        'At your first visit we take time to understand your dental history, listen to any concerns, and carry out a thorough examination. We then talk through our findings in plain language and recommend a clear, straightforward plan — no pressure, no jargon.',
    },
    {
      slug: 'cosmetic-dentistry',
      name: 'Cosmetic Dentistry',
      category: 'Smile Design',
      shortDescription: 'Teeth whitening, veneers and smile-focused treatments.',
      image:
        'https://images.pexels.com/photos/6627571/pexels-photo-6627571.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'Cosmetic dentistry is about enhancing the appearance of your smile while keeping it looking natural. This includes whitening, veneers, bonding, and other smile-focused treatments tailored to the proportions and character of your face — never a uniform, artificial look.',
      suitableFor:
        'If you are happy with the function of your teeth but would like to feel more confident about their appearance — whether that is brightness, shape, or alignment — cosmetic dentistry may be suitable for you.',
      consultationProcess:
        'We start with a conversation about what you like and don\'t like about your smile. From there we can discuss options, show you examples, and design a plan that suits your goals — always with natural-looking results in mind.',
    },
    {
      slug: 'teeth-whitening',
      name: 'Teeth Whitening',
      category: 'Cosmetic',
      shortDescription: 'Brighten your smile with professional whitening.',
      image:
        'https://images.pexels.com/photos/3762402/pexels-photo-3762402.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'Professional teeth whitening is a safe, effective way to brighten your smile. Unlike over-the-counter products, professional whitening is tailored to your enamel and sensitivity levels, giving you a noticeably fresher smile with results you can control.',
      suitableFor:
        'If your teeth are generally healthy but have become stained or dulled over time — from coffee, tea, food, or simply age — whitening may be a straightforward way to refresh your smile.',
      consultationProcess:
        'We assess your teeth and gums to make sure whitening is appropriate, discuss the shade you would like to achieve, and recommend the best approach — whether that is in-practice or a custom take-home kit.',
    },
    {
      slug: 'veneers',
      name: 'Veneers',
      category: 'Cosmetic',
      shortDescription: 'Thin, natural-looking shells for a refined smile.',
      image:
        'https://images.pexels.com/photos/6627572/pexels-photo-6627572.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'Veneers are ultra-thin, custom-made shells that are bonded to the front of your teeth. They can refine the shape, shade, and alignment of your smile while preserving as much of your natural tooth as possible. The goal is a result that looks like you — only more confident.',
      suitableFor:
        'If you are looking to refine the shape, size, or colour of specific teeth, or to address minor gaps and chips, veneers may be worth exploring as part of a smile design.',
      consultationProcess:
        'We discuss the look you want to achieve, assess your teeth, and design a preview of your potential smile. You will have the chance to review and adjust before any treatment begins.',
    },
    {
      slug: 'dental-implants',
      name: 'Dental Implants',
      category: 'Restorative',
      shortDescription: 'Modern solutions for replacing missing teeth.',
      image:
        'https://images.pexels.com/photos/6502305/pexels-photo-6502305.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'Dental implants are a long-term solution for replacing missing teeth. A small titanium post is placed in the jaw, and a natural-looking crown is fitted on top — restoring both the appearance and function of your smile without affecting neighbouring teeth.',
      suitableFor:
        'If you are missing one or more teeth and would like a stable, long-lasting alternative to dentures or bridges, implants may be suitable. A consultation will help determine whether your bone and gum health support the treatment.',
      consultationProcess:
        'We carry out a thorough assessment including imaging, explain the process step by step, and make sure you feel comfortable with every stage before we begin. Treatment is planned around your comfort and timeline.',
    },
    {
      slug: 'clear-aligners',
      name: 'Clear Aligners',
      category: 'Orthodontic',
      shortDescription: 'A discreet approach to straightening teeth.',
      image:
        'https://images.pexels.com/photos/28407749/pexels-photo-28407749.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'Clear aligners are a discreet, removable alternative to traditional braces. A series of custom-made, near-invisible trays gradually guide your teeth into alignment — so you can straighten your smile without it being obvious to everyone around you.',
      suitableFor:
        'If you would like to straighten crooked, crowded, or gapped teeth but prefer not to wear fixed metal braces, clear aligners may be a suitable option.',
      consultationProcess:
        'We assess your bite and alignment, discuss your goals, and show you a preview of the expected movement. You will know the estimated duration and cost before deciding to go ahead.',
    },
    {
      slug: 'smile-makeovers',
      name: 'Smile Makeovers',
      category: 'Comprehensive',
      shortDescription: 'A complete, tailored smile transformation.',
      image:
        'https://images.pexels.com/photos/6627575/pexels-photo-6627575.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'A smile makeover is a fully personalised combination of treatments designed together — which may include whitening, veneers, aligners, or restorative work. The aim is a harmonious, natural-looking result that complements your face and fits your lifestyle.',
      suitableFor:
        'If you have several concerns about your smile and are not sure where to start, a smile makeover gives you a clear, joined-up plan rather than a piecemeal approach.',
      consultationProcess:
        'We take time to understand the outcome you are hoping for, assess your teeth comprehensively, and design a step-by-step plan. You will see a preview of the expected result and understand each stage before we begin.',
    },
    {
      slug: 'emergency-dental-care',
      name: 'Emergency Dental Care',
      category: 'Urgent',
      shortDescription: 'Prompt care when you need it most.',
      image:
        'https://images.pexels.com/photos/6502543/pexels-photo-6502543.jpeg?auto=compress&cs=tinysrgb&w=800',
      whatItIs:
        'Dental emergencies happen — a broken tooth, sudden pain, or a lost filling. We set aside appointments for urgent concerns so you can be seen promptly and comfortably, with clear advice on what to do next.',
      suitableFor:
        'If you are in pain, have damaged a tooth, or have an urgent dental concern, contact us as early in the day as possible and we will do our best to see you the same day.',
      consultationProcess:
        'Call or WhatsApp us with details of your concern. We will triage over the phone, give you immediate advice, and arrange the earliest available appointment.',
    },
  ],

  // ---- BEFORE & AFTER TRANSFORMATIONS ----
  transformations: [
    {
      id: 'case-1',
      title: 'Veneer Smile Refinement',
      category: 'Cosmetic Dentistry',
      description:
        'Subtle veneers used to refine tooth shape and create a brighter, more uniform smile.',
      beforeImage:
        'https://images.pexels.com/photos/65665/smile-mouth-teeth-laugh-65665.jpeg?auto=compress&cs=tinysrgb&w=1200',
      afterImage:
        'https://images.pexels.com/photos/3762402/pexels-photo-3762402.jpeg?auto=compress&cs=tinysrgb&w=1200',
    },
    {
      id: 'case-2',
      title: 'Clear Aligner Straightening',
      category: 'Clear Aligners',
      description:
        'Discreet aligners used over several months to correct crowding and alignment.',
      beforeImage:
        'https://images.pexels.com/photos/41208/fun-cold-elegance-face-41208.jpeg?auto=compress&cs=tinysrgb&w=1200',
      afterImage:
        'https://images.pexels.com/photos/28110692/pexels-photo-28110692.jpeg?auto=compress&cs=tinysrgb&w=1200',
    },
    {
      id: 'case-3',
      title: 'Whitening & Restoration',
      category: 'Teeth Whitening',
      description:
        'Professional whitening combined with minor restorative work for a refreshed smile.',
      beforeImage:
        'https://images.pexels.com/photos/65665/smile-mouth-teeth-laugh-65665.jpeg?auto=compress&cs=tinysrgb&w=1200',
      afterImage:
        'https://images.pexels.com/photos/3762453/pexels-photo-3762453.jpeg?auto=compress&cs=tinysrgb&w=1200',
    },
  ],

  // ---- TESTIMONIALS ----
  testimonials: [
    {
      name: 'Sarah M.',
      text: 'I was nervous before my first appointment, but everything was explained clearly and I never felt rushed. The whole experience was much calmer than I expected.',
    },
    {
      name: 'James P.',
      text: 'I hadn\'t been to a dentist in years. The team put me at ease straight away and gave me a plan that made sense without any pressure. Really glad I went.',
    },
    {
      name: 'Nadia K.',
      text: 'The difference in my smile is subtle but I feel so much more confident. Dr. Rahman listened to exactly what I wanted and the results look completely natural.',
    },
  ],

  // ---- WHATSAPP ----
  whatsappMessage:
    "Hi, I'd like to enquire about booking a dental consultation.",
};
