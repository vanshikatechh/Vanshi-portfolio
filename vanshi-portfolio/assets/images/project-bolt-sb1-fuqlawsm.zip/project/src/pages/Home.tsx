import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  MessageCircle,
  Calendar,
  ShieldCheck,
  Heart,
  Stethoscope,
  Clock,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Quote,
} from 'lucide-react';
import { clinicConfig } from '@/config/clinic';
import { whatsappLink } from '@/lib/whatsapp';
import { useReveal } from '@/hooks/useReveal';
import BeforeAfterSlider from '@/components/BeforeAfterSlider';
import SectionHeading from '@/components/SectionHeading';
import CTASection from '@/components/CTASection';

const trustIndicators = [
  { icon: Stethoscope, text: 'Personalised Treatment Plans' },
  { icon: Sparkles, text: 'Modern Dental Care' },
  { icon: Heart, text: 'Comfortable Patient Experience' },
  { icon: Calendar, text: 'Easy Appointment Booking' },
];

const concerns = [
  {
    quote: "I'm nervous about dental treatment.",
    response:
      "You're not alone — many of our patients felt the same way before their first visit. We take time to explain every step, move at your pace, and never rush. Comfort isn't an add-on; it's how we work.",
  },
  {
    quote: "I want my smile to look natural.",
    response:
      "Our approach to cosmetic dentistry is designed around subtlety. We work to the proportions of your face and the character of your smile, so results look like you — only more confident.",
  },
  {
    quote: "I don't know which treatment is right for me.",
    response:
      "That's exactly what the consultation is for. We assess your teeth, listen to what you want to achieve, and explain suitable options in plain language. You decide — we guide.",
  },
];

const journeySteps = [
  { number: '01', title: 'Consultation', text: 'We listen to your concerns and goals.' },
  { number: '02', title: 'Personalised Plan', text: 'We explain suitable treatment options clearly.' },
  { number: '03', title: 'Treatment', text: 'Comfortable, modern care at every stage.' },
  { number: '04', title: 'Smile With Confidence', text: 'Ongoing guidance and aftercare.' },
];

const experienceBenefits = [
  { title: 'Calm environment', text: 'A quiet, unhurried space designed to put you at ease from the moment you arrive.' },
  { title: 'Clear treatment explanations', text: 'We talk through every option in plain language so you always know what to expect.' },
  { title: 'Comfort-first appointments', text: 'Generous appointment times mean we never rush your care.' },
  { title: 'Personalised care', text: 'Every plan is built around your goals, your comfort, and your smile.' },
];

const featuredTreatments = [
  {
    name: 'Cosmetic Dentistry',
    description: 'Teeth whitening, veneers and smile-focused treatments.',
    image: 'https://images.pexels.com/photos/6627571/pexels-photo-6627571.jpeg?auto=compress&cs=tinysrgb&w=800',
    slug: 'cosmetic-dentistry',
  },
  {
    name: 'Dental Implants',
    description: 'Modern solutions for replacing missing teeth.',
    image: 'https://images.pexels.com/photos/6502305/pexels-photo-6502305.jpeg?auto=compress&cs=tinysrgb&w=800',
    slug: 'dental-implants',
  },
  {
    name: 'Clear Aligners',
    description: 'A discreet approach to straightening teeth.',
    image: 'https://images.pexels.com/photos/28407749/pexels-photo-28407749.jpeg?auto=compress&cs=tinysrgb&w=800',
    slug: 'clear-aligners',
  },
  {
    name: 'General Dentistry',
    description: 'Preventive and restorative dental care.',
    image: 'https://images.pexels.com/photos/5622270/pexels-photo-5622270.jpeg?auto=compress&cs=tinysrgb&w=800',
    slug: 'general-dentistry',
  },
];

function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-24 pb-16 px-5 sm:px-8 lg:px-12 overflow-hidden">
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
        {/* Left */}
        <div className="order-2 lg:order-1">
          <p className="text-xs sm:text-sm tracking-[0.25em] uppercase text-sage-600 font-semibold mb-6 animate-fade-up">
            Modern Dentistry &bull; Natural Results
          </p>
          <h1 className="font-serif text-display font-semibold text-navy-900 mb-6 animate-fade-up" style={{ animationDelay: '0.1s' }}>
            A healthier smile.<br />
            A more confident you.
          </h1>
          <p className="text-navy-600 text-lg leading-relaxed max-w-lg mb-8 animate-fade-up" style={{ animationDelay: '0.2s' }}>
            {clinicConfig.shortDescription}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 animate-fade-up" style={{ animationDelay: '0.3s' }}>
            <Link
              to="/contact"
              className="flex items-center justify-center gap-2 px-7 py-4 text-sm font-medium text-white bg-navy-900 rounded-full hover:bg-sage-600 transition-all duration-300 shadow-lg shadow-navy-900/10"
            >
              <Calendar className="w-4 h-4" />
              Book a Consultation
            </Link>
            <Link
              to="/treatments"
              className="flex items-center justify-center gap-2 px-7 py-4 text-sm font-medium text-navy-700 border border-navy-200 rounded-full hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all duration-300"
            >
              Explore Treatments
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Right */}
        <div className="order-1 lg:order-2 relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <div className="relative rounded-[2rem] overflow-hidden shadow-2xl">
            <img
              src={clinicConfig.images.hero}
              alt={clinicConfig.images.heroAlt}
              className="w-full h-[400px] sm:h-[500px] lg:h-[600px] object-cover"
            />
          </div>
          {/* Floating cards */}
          <div className="absolute -left-4 sm:left-6 top-1/4 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl px-5 py-3.5 animate-float">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-sage-100 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-sage-600" />
              </div>
              <div>
                <p className="text-xs font-semibold text-navy-900">Taking new patients</p>
                <p className="text-[11px] text-navy-500">Now accepting bookings</p>
              </div>
            </div>
          </div>
          <div className="absolute -right-2 sm:right-4 bottom-1/4 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl px-5 py-3.5 animate-float-delayed">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-teal-100 flex items-center justify-center">
                <Heart className="w-4 h-4 text-teal-600" />
              </div>
              <div>
                <p className="text-xs font-semibold text-navy-900">Comfort-first care</p>
                <p className="text-[11px] text-navy-500">Your pace, your plan</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustStrip() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-12 px-5 sm:px-8 lg:px-12 border-y border-ivory-200 bg-ivory-100">
      <div
        ref={ref}
        className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8`}
      >
        {trustIndicators.map((item) => (
          <div key={item.text} className="flex items-center gap-3 justify-center text-center lg:flex-row">
            <div className="w-10 h-10 rounded-full bg-sage-100 flex items-center justify-center shrink-0">
              <item.icon className="w-5 h-5 text-sage-600" />
            </div>
            <p className="text-sm font-medium text-navy-700 leading-snug">{item.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function ProblemSolution() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-5xl mx-auto`}>
        <SectionHeading
          eyebrow="Your Concerns, Understood"
          title="Your smile deserves more than a one-size-fits-all approach."
          subtitle="Every patient arrives with different questions. Here's how we approach the ones we hear most often."
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mt-14">
          {concerns.map((item, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-7 border border-ivory-200 hover:shadow-xl hover:border-sage-200 transition-all duration-400"
            >
              <Quote className="w-8 h-8 text-sage-300 mb-4" />
              <p className="font-serif text-xl text-navy-900 mb-4 leading-snug italic">
                {item.quote}
              </p>
              <p className="text-sm text-navy-600 leading-relaxed">{item.response}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeaturedTreatments() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12 bg-ivory-100">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto`}>
        <SectionHeading
          eyebrow="Featured Treatments"
          title="Care designed around your smile"
          subtitle="From cosmetic refinements to restorative solutions, every treatment is tailored to you."
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-14">
          {featuredTreatments.map((t) => (
            <Link
              key={t.slug}
              to={`/treatments#${t.slug}`}
              className="group bg-white rounded-2xl overflow-hidden border border-ivory-200 hover:shadow-xl transition-all duration-400"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={t.image}
                  alt={t.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950/30 to-transparent" />
              </div>
              <div className="p-6">
                <h3 className="font-serif text-xl font-semibold text-navy-900 mb-2">{t.name}</h3>
                <p className="text-sm text-navy-600 leading-relaxed mb-4">{t.description}</p>
                <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-sage-600 group-hover:gap-2.5 transition-all">
                  Explore treatment
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

function BeforeAfterSection() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  const [activeCase, setActiveCase] = useState(0);
  const cases = clinicConfig.transformations;

  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-5xl mx-auto`}>
        <SectionHeading
          eyebrow="Real Results"
          title="See the difference."
          subtitle="Explore examples of smile transformations. Drag the slider to compare before and after."
        />
        <div className="mt-12">
          <BeforeAfterSlider
            beforeImage={cases[activeCase].beforeImage}
            afterImage={cases[activeCase].afterImage}
            beforeAlt={`Before: ${cases[activeCase].title}`}
            afterAlt={`After: ${cases[activeCase].title}`}
            className="max-w-4xl mx-auto"
          />
          {/* Case selector */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-6">
            {cases.map((c, i) => (
              <button
                key={c.id}
                onClick={() => setActiveCase(i)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  i === activeCase
                    ? 'bg-navy-900 text-white'
                    : 'bg-ivory-100 text-navy-600 hover:bg-ivory-200'
                }`}
              >
                {c.title}
              </button>
            ))}
          </div>
          <p className="text-center text-navy-600 text-sm mt-4">
            {cases[activeCase].description}
          </p>
        </div>
        <div className="text-center mt-10">
          <p className="font-serif text-xl text-navy-900 mb-4 italic">
            Every smile is different. Your treatment plan should be too.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 text-sm font-semibold text-navy-900 hover:text-sage-600 transition-colors group"
          >
            Discuss Your Smile
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function PatientJourney() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12 bg-navy-900 text-white">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-6xl mx-auto`}>
        <SectionHeading
          eyebrow="Your Journey"
          title="From first visit to confident smile"
          subtitle="A clear, unhurried process designed around your comfort at every stage."
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-14">
          {journeySteps.map((step) => (
            <div key={step.number} className="relative">
              <span className="font-serif text-5xl font-semibold text-sage-300/40 block mb-3">
                {step.number}
              </span>
              <h3 className="font-serif text-xl font-semibold text-white mb-2">{step.title}</h3>
              <p className="text-sm text-ivory-200/70 leading-relaxed">{step.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function DentistSection() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center`}>
        <div className="relative">
          <div className="rounded-[2rem] overflow-hidden shadow-xl">
            <img
              src={clinicConfig.dentist.portrait}
              alt={`${clinicConfig.dentist.name}, ${clinicConfig.dentist.role}`}
              className="w-full h-[450px] lg:h-[560px] object-cover"
              loading="lazy"
            />
          </div>
          <div className="absolute -bottom-6 -right-4 sm:right-8 bg-white rounded-2xl shadow-xl px-6 py-4">
            <p className="font-serif text-lg font-semibold text-navy-900">{clinicConfig.dentist.name}</p>
            <p className="text-xs text-sage-600 font-medium tracking-wide">{clinicConfig.dentist.role}</p>
          </div>
        </div>
        <div>
          <p className="text-xs sm:text-sm tracking-[0.2em] uppercase text-sage-600 font-semibold mb-4">
            Your Dentist
          </p>
          <h2 className="font-serif text-heading font-semibold text-navy-900 mb-6">
            Meet the dentist behind your care
          </h2>
          <p className="text-navy-600 text-base leading-relaxed mb-5">
            {clinicConfig.dentist.bio}
          </p>
          <div className="bg-ivory-100 rounded-2xl p-6 mb-6 border-l-4 border-sage-500">
            <p className="font-serif text-lg italic text-navy-700 leading-relaxed">
              "{clinicConfig.dentist.philosophy}"
            </p>
          </div>
          <div className="flex flex-wrap gap-2 mb-8">
            {clinicConfig.dentist.interests.map((interest) => (
              <span key={interest} className="px-4 py-1.5 text-xs font-medium text-navy-700 bg-ivory-200 rounded-full">
                {interest}
              </span>
            ))}
          </div>
          <Link
            to="/about"
            className="inline-flex items-center gap-2 text-sm font-semibold text-navy-900 hover:text-sage-600 transition-colors group"
          >
            Meet the Dentist
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function PatientExperienceSection() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12 bg-ivory-100">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto`}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-14">
          <div>
            <p className="text-xs sm:text-sm tracking-[0.2em] uppercase text-sage-600 font-semibold mb-4">
              Patient Experience
            </p>
            <h2 className="font-serif text-heading font-semibold text-navy-900 mb-5">
              Dental care should feel different.
            </h2>
            <p className="text-navy-600 text-base leading-relaxed">
              From the atmosphere to the way we explain treatment, everything is designed to make your visit feel calm, clear, and unhurried.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img
              src={clinicConfig.images.clinicInterior[0]}
              alt="Modern dental clinic interior"
              className="rounded-2xl h-64 w-full object-cover shadow-lg"
              loading="lazy"
            />
            <img
              src={clinicConfig.images.clinicInterior[1]}
              alt="Dental treatment room"
              className="rounded-2xl h-64 w-full object-cover shadow-lg mt-8"
              loading="lazy"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {experienceBenefits.map((b) => (
            <div key={b.title} className="bg-white rounded-2xl p-6 border border-ivory-200 hover:shadow-lg transition-all duration-300">
              <div className="w-10 h-10 rounded-full bg-sage-100 flex items-center justify-center mb-4">
                <Heart className="w-5 h-5 text-sage-600" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-navy-900 mb-2">{b.title}</h3>
              <p className="text-sm text-navy-600 leading-relaxed">{b.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  const [active, setActive] = useState(0);
  const testimonials = clinicConfig.testimonials;

  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-4xl mx-auto`}>
        <SectionHeading
          eyebrow="Patient Stories"
          title="What patients say"
          subtitle="Real words from real visits — no exaggeration, no scripts."
        />
        <div className="mt-12 relative">
          <div className="bg-white rounded-2xl p-8 sm:p-12 border border-ivory-200 shadow-lg text-center">
            <Quote className="w-10 h-10 text-sage-300 mx-auto mb-6" />
            <p className="font-serif text-xl sm:text-2xl text-navy-800 leading-relaxed italic mb-8">
              {testimonials[active].text}
            </p>
            <p className="text-sm font-semibold text-navy-900 tracking-wide">
              {testimonials[active].name}
            </p>
          </div>
          <div className="flex items-center justify-center gap-4 mt-6">
            <button
              onClick={() => setActive((a) => (a - 1 + testimonials.length) % testimonials.length)}
              className="w-10 h-10 rounded-full border border-navy-200 flex items-center justify-center hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    i === active ? 'w-6 bg-sage-600' : 'w-2 bg-navy-200'
                  }`}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>
            <button
              onClick={() => setActive((a) => (a + 1) % testimonials.length)}
              className="w-10 h-10 rounded-full border border-navy-200 flex items-center justify-center hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <div className="page-enter">
      <Hero />
      <TrustStrip />
      <ProblemSolution />
      <FeaturedTreatments />
      <BeforeAfterSection />
      <PatientJourney />
      <DentistSection />
      <PatientExperienceSection />
      <Testimonials />
      <CTASection />
    </div>
  );
}
