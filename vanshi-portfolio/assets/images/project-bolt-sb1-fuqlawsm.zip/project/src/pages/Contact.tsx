import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle, CheckCircle2, Calendar } from 'lucide-react';
import { clinicConfig } from '@/config/clinic';
import { whatsappLink } from '@/lib/whatsapp';
import { useReveal } from '@/hooks/useReveal';

interface FormData {
  name: string;
  phone: string;
  email: string;
  treatment: string;
  preferredDate: string;
  message: string;
}

interface FormErrors {
  name?: string;
  phone?: string;
  email?: string;
  treatment?: string;
  preferredDate?: string;
}

function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};
  if (!data.name.trim()) errors.name = 'Please enter your name.';
  if (!data.phone.trim()) {
    errors.phone = 'Please enter your phone number.';
  } else if (!/^[+]?[\d\s()-]{7,}$/.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number.';
  }
  if (!data.email.trim()) {
    errors.email = 'Please enter your email.';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!data.treatment) errors.treatment = 'Please select a treatment.';
  if (!data.preferredDate) errors.preferredDate = 'Please choose a preferred date.';
  return errors;
}

function ContactInfo() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''}`}>
      <h2 className="font-serif text-2xl font-semibold text-navy-900 mb-6">
        Get in touch
      </h2>
      <div className="space-y-5">
        <a href={clinicConfig.contact.phoneHref} className="flex items-center gap-4 group">
          <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center shrink-0 group-hover:bg-sage-600 transition-colors duration-300">
            <Phone className="w-5 h-5 text-sage-600 group-hover:text-white transition-colors duration-300" />
          </div>
          <div>
            <p className="text-xs text-navy-500 uppercase tracking-wide">Phone</p>
            <p className="text-sm font-medium text-navy-900">{clinicConfig.contact.phone}</p>
          </div>
        </a>
        <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
          <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center shrink-0 group-hover:bg-sage-600 transition-colors duration-300">
            <MessageCircle className="w-5 h-5 text-sage-600 group-hover:text-white transition-colors duration-300" />
          </div>
          <div>
            <p className="text-xs text-navy-500 uppercase tracking-wide">WhatsApp</p>
            <p className="text-sm font-medium text-navy-900">{clinicConfig.contact.whatsapp}</p>
          </div>
        </a>
        <a href={`mailto:${clinicConfig.contact.email}`} className="flex items-center gap-4 group">
          <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center shrink-0 group-hover:bg-sage-600 transition-colors duration-300">
            <Mail className="w-5 h-5 text-sage-600 group-hover:text-white transition-colors duration-300" />
          </div>
          <div>
            <p className="text-xs text-navy-500 uppercase tracking-wide">Email</p>
            <p className="text-sm font-medium text-navy-900">{clinicConfig.contact.email}</p>
          </div>
        </a>
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center shrink-0">
            <MapPin className="w-5 h-5 text-sage-600" />
          </div>
          <div>
            <p className="text-xs text-navy-500 uppercase tracking-wide">Address</p>
            <p className="text-sm font-medium text-navy-900 leading-relaxed">
              {clinicConfig.contact.address.line1}, {clinicConfig.contact.address.line2}
              <br />
              {clinicConfig.contact.address.city}, {clinicConfig.contact.address.postcode}
            </p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5 text-sage-600" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-navy-500 uppercase tracking-wide mb-2">Opening Hours</p>
            <ul className="space-y-1">
              {clinicConfig.hours.map((h) => (
                <li key={h.day} className="flex justify-between text-sm">
                  <span className="text-navy-700">{h.day}</span>
                  <span className={h.time === 'Closed' ? 'text-navy-400' : 'text-navy-900 font-medium'}>
                    {h.time}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <a
        href={whatsappLink()}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 mt-8 w-full px-6 py-3.5 text-sm font-medium text-white bg-sage-600 rounded-full hover:bg-sage-700 transition-all duration-300"
      >
        <MessageCircle className="w-4 h-4" />
        Message us on WhatsApp
      </a>
    </div>
  );
}

function BookingForm() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    phone: '',
    email: '',
    treatment: '',
    preferredDate: '',
    message: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const { ref, revealed } = useReveal<HTMLDivElement>();

  const handleChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field as keyof FormErrors]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateForm(formData);
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} bg-white rounded-2xl p-8 sm:p-12 border border-ivory-200 shadow-lg text-center`}>
        <div className="w-16 h-16 rounded-full bg-sage-100 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-8 h-8 text-sage-600" />
        </div>
        <h3 className="font-serif text-2xl font-semibold text-navy-900 mb-3">
          Thank you, {formData.name.split(' ')[0]}.
        </h3>
        <p className="text-navy-600 text-sm leading-relaxed mb-6 max-w-sm mx-auto">
          Your appointment request has been received. We'll contact you within one business day to confirm your consultation.
        </p>
        <p className="text-xs text-navy-500 mb-6">
          For urgent enquiries, please WhatsApp or call us directly.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium text-white bg-sage-600 rounded-full hover:bg-sage-700 transition-all"
          >
            <MessageCircle className="w-4 h-4" />
            WhatsApp Us
          </a>
          <button
            onClick={() => {
              setSubmitted(false);
              setFormData({ name: '', phone: '', email: '', treatment: '', preferredDate: '', message: '' });
            }}
            className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium text-navy-700 border border-navy-200 rounded-full hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all"
          >
            Send another request
          </button>
        </div>
      </div>
    );
  }

  return (
    <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} bg-white rounded-2xl p-6 sm:p-8 border border-ivory-200 shadow-lg`}>
      <h2 className="font-serif text-2xl font-semibold text-navy-900 mb-2">
        Request an appointment
      </h2>
      <p className="text-sm text-navy-500 mb-6">
        Fill in the form below and we'll be in touch to confirm your consultation.
      </p>
      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-xs font-semibold text-navy-700 mb-1.5">
            Name *
          </label>
          <input
            id="name"
            type="text"
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            className={`w-full px-4 py-3 text-sm rounded-xl border bg-ivory-50 focus:outline-none focus:ring-2 transition-all ${
              errors.name
                ? 'border-red-400 focus:ring-red-200'
                : 'border-ivory-300 focus:border-sage-400 focus:ring-sage-100'
            }`}
            placeholder="Your full name"
          />
          {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="phone" className="block text-xs font-semibold text-navy-700 mb-1.5">
              Phone *
            </label>
            <input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              className={`w-full px-4 py-3 text-sm rounded-xl border bg-ivory-50 focus:outline-none focus:ring-2 transition-all ${
                errors.phone
                  ? 'border-red-400 focus:ring-red-200'
                  : 'border-ivory-300 focus:border-sage-400 focus:ring-sage-100'
              }`}
              placeholder="Your phone number"
            />
            {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone}</p>}
          </div>
          <div>
            <label htmlFor="email" className="block text-xs font-semibold text-navy-700 mb-1.5">
              Email *
            </label>
            <input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleChange('email', e.target.value)}
              className={`w-full px-4 py-3 text-sm rounded-xl border bg-ivory-50 focus:outline-none focus:ring-2 transition-all ${
                errors.email
                  ? 'border-red-400 focus:ring-red-200'
                  : 'border-ivory-300 focus:border-sage-400 focus:ring-sage-100'
              }`}
              placeholder="you@email.com"
            />
            {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="treatment" className="block text-xs font-semibold text-navy-700 mb-1.5">
              Treatment interested in *
            </label>
            <select
              id="treatment"
              value={formData.treatment}
              onChange={(e) => handleChange('treatment', e.target.value)}
              className={`w-full px-4 py-3 text-sm rounded-xl border bg-ivory-50 focus:outline-none focus:ring-2 transition-all ${
                errors.treatment
                  ? 'border-red-400 focus:ring-red-200'
                  : 'border-ivory-300 focus:border-sage-400 focus:ring-sage-100'
              }`}
            >
              <option value="">Select a treatment</option>
              {clinicConfig.treatments.map((t) => (
                <option key={t.slug} value={t.name}>{t.name}</option>
              ))}
              <option value="Not sure yet">Not sure yet — need guidance</option>
            </select>
            {errors.treatment && <p className="text-xs text-red-500 mt-1">{errors.treatment}</p>}
          </div>
          <div>
            <label htmlFor="preferredDate" className="block text-xs font-semibold text-navy-700 mb-1.5">
              Preferred date *
            </label>
            <input
              id="preferredDate"
              type="date"
              value={formData.preferredDate}
              onChange={(e) => handleChange('preferredDate', e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className={`w-full px-4 py-3 text-sm rounded-xl border bg-ivory-50 focus:outline-none focus:ring-2 transition-all ${
                errors.preferredDate
                  ? 'border-red-400 focus:ring-red-200'
                  : 'border-ivory-300 focus:border-sage-400 focus:ring-sage-100'
              }`}
            />
            {errors.preferredDate && <p className="text-xs text-red-500 mt-1">{errors.preferredDate}</p>}
          </div>
        </div>

        <div>
          <label htmlFor="message" className="block text-xs font-semibold text-navy-700 mb-1.5">
            Message
          </label>
          <textarea
            id="message"
            rows={4}
            value={formData.message}
            onChange={(e) => handleChange('message', e.target.value)}
            className="w-full px-4 py-3 text-sm rounded-xl border border-ivory-300 bg-ivory-50 focus:outline-none focus:ring-2 focus:border-sage-400 focus:ring-sage-100 transition-all resize-none"
            placeholder="Tell us what you'd like to improve or any questions you have..."
          />
        </div>

        <button
          type="submit"
          className="flex items-center justify-center gap-2 w-full px-6 py-4 text-sm font-medium text-white bg-navy-900 rounded-full hover:bg-sage-600 transition-all duration-300 shadow-lg shadow-navy-900/10"
        >
          <Calendar className="w-4 h-4" />
          Request Appointment
        </button>
      </form>
    </div>
  );
}

export default function Contact() {
  return (
    <div className="page-enter">
      <section className="pt-32 pb-16 px-5 sm:px-8 lg:px-12 bg-ivory-100">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xs sm:text-sm tracking-[0.25em] uppercase text-sage-600 font-semibold mb-4">
            Book a Consultation
          </p>
          <h1 className="font-serif text-display font-semibold text-navy-900 mb-5">
            Let's talk about your smile
          </h1>
          <p className="text-navy-600 text-lg leading-relaxed">
            Send us a message or book online. We'll help you understand your options — no pressure, no jargon.
          </p>
        </div>
      </section>

      <section className="py-16 sm:py-24 px-5 sm:px-8 lg:px-12">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-12">
          <div className="lg:col-span-2">
            <ContactInfo />
          </div>
          <div className="lg:col-span-3">
            <BookingForm />
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="px-5 sm:px-8 lg:px-12 pb-20">
        <div className="max-w-7xl mx-auto">
          <div className="rounded-2xl overflow-hidden shadow-lg border border-ivory-200 h-[360px] bg-ivory-200">
            <iframe
              title="Clinic location map"
              src={clinicConfig.contact.mapsEmbed}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <p className="text-center text-xs text-navy-500 mt-3">
            <a href={clinicConfig.contact.mapsLink} target="_blank" rel="noopener noreferrer" className="hover:text-sage-600 transition-colors">
              Open in Google Maps →
            </a>
          </p>
        </div>
      </section>
    </div>
  );
}
