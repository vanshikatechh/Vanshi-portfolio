import { clinicConfig } from '@/config/clinic';
import { useReveal } from '@/hooks/useReveal';
import BeforeAfterSlider from '@/components/BeforeAfterSlider';
import CTASection from '@/components/CTASection';

function CaseCard({ transformation, index }: { transformation: typeof clinicConfig.transformations[0]; index: number }) {
  const { ref, revealed } = useReveal<HTMLDivElement>();

  return (
    <div
      ref={ref}
      className={`reveal ${revealed ? 'revealed' : ''} ${
        index % 2 === 0 ? 'lg:pr-12' : 'lg:pl-12 lg:mt-24'
      }`}
    >
      <div className="mb-5">
        <span className="inline-block px-3 py-1 text-xs font-medium text-sage-700 bg-sage-50 rounded-full mb-3">
          {transformation.category}
        </span>
        <h3 className="font-serif text-2xl font-semibold text-navy-900 mb-2">
          {transformation.title}
        </h3>
        <p className="text-sm text-navy-600 leading-relaxed max-w-lg">
          {transformation.description}
        </p>
      </div>
      <BeforeAfterSlider
        beforeImage={transformation.beforeImage}
        afterImage={transformation.afterImage}
        beforeAlt={`Before: ${transformation.title}`}
        afterAlt={`After: ${transformation.title}`}
      />
    </div>
  );
}

export default function BeforeAfter() {
  const { ref, revealed } = useReveal<HTMLDivElement>();

  return (
    <div className="page-enter">
      {/* Hero */}
      <section className="pt-32 pb-16 px-5 sm:px-8 lg:px-12 bg-ivory-100">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xs sm:text-sm tracking-[0.25em] uppercase text-sage-600 font-semibold mb-4">
            Smile Transformations
          </p>
          <h1 className="font-serif text-display font-semibold text-navy-900 mb-5">
            Before &amp; After
          </h1>
          <p className="text-navy-600 text-lg leading-relaxed">
            Explore examples of smile transformations. Drag the slider on each case to see the difference.
          </p>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 sm:py-24 px-5 sm:px-8 lg:px-12">
        <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-6xl mx-auto`}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8">
            {clinicConfig.transformations.map((t, i) => (
              <CaseCard key={t.id} transformation={t} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="px-5 sm:px-8 lg:px-12 pb-8">
        <div className="max-w-3xl mx-auto bg-ivory-100 rounded-2xl p-6 text-center border border-ivory-200">
          <p className="text-sm text-navy-500 leading-relaxed">
            Results vary between patients. Images shown are for demonstration purposes.
          </p>
        </div>
      </section>

      <CTASection
        title="Imagine your smile transformation."
        subtitle="Book a consultation to discuss what's possible — we'll help you understand your options clearly."
      />
    </div>
  );
}
