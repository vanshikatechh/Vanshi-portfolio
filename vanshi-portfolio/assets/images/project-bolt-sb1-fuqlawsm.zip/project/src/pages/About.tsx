import { Link } from 'react-router-dom';
import { ArrowRight, Heart, Eye, ShieldCheck, Sparkles } from 'lucide-react';
import { clinicConfig } from '@/config/clinic';
import { useReveal } from '@/hooks/useReveal';
import SectionHeading from '@/components/SectionHeading';
import CTASection from '@/components/CTASection';

const philosophyPoints = [
  { icon: Heart, title: 'Comfort comes first', text: 'We move at your pace, explain every step, and never rush your care.' },
  { icon: Eye, title: 'Natural-looking results', text: 'Our cosmetic work is designed to look like you — only more confident.' },
  { icon: ShieldCheck, title: 'Honest, clear advice', text: 'We only recommend treatment that genuinely suits your needs and goals.' },
  { icon: Sparkles, title: 'Modern, considered care', text: 'We combine modern technique with a calm, unhurried chairside manner.' },
];

const whyChoose = [
  'A calm, welcoming environment from the moment you arrive',
  'Clear, jargon-free explanations of every treatment option',
  'Personalised plans designed around your goals and timeline',
  'Generous appointment times — we never rush your care',
  'A dentist who listens before she treats',
];

function PageHero() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="pt-32 pb-16 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center`}>
        <div>
          <p className="text-xs sm:text-sm tracking-[0.25em] uppercase text-sage-600 font-semibold mb-4">
            About {clinicConfig.name.split(' ')[0]}
          </p>
          <h1 className="font-serif text-display font-semibold text-navy-900 mb-5">
            Dentistry designed around people
          </h1>
          <p className="text-navy-600 text-lg leading-relaxed max-w-lg">
            We built {clinicConfig.name} on a simple belief: dental care should feel calm, clear, and personal — never rushed or impersonal.
          </p>
        </div>
        <div className="rounded-[2rem] overflow-hidden shadow-xl">
          <img
            src={clinicConfig.images.clinicInterior[0]}
            alt="Clinic interior"
            className="w-full h-[320px] lg:h-[400px] object-cover"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
}

function Philosophy() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 px-5 sm:px-8 lg:px-12 bg-ivory-100">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-6xl mx-auto`}>
        <SectionHeading
          eyebrow="Our Philosophy"
          title="What we believe"
          subtitle="Four principles that shape every appointment and every treatment plan."
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-14">
          {philosophyPoints.map((p) => (
            <div key={p.title} className="bg-white rounded-2xl p-7 border border-ivory-200 hover:shadow-lg transition-all duration-300">
              <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center mb-5">
                <p.icon className="w-5 h-5 text-sage-600" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-navy-900 mb-2">{p.title}</h3>
              <p className="text-sm text-navy-600 leading-relaxed">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function MeetDentist() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center`}>
        <div className="relative">
          <div className="rounded-[2rem] overflow-hidden shadow-xl">
            <img
              src={clinicConfig.dentist.portrait}
              alt={`${clinicConfig.dentist.name}, ${clinicConfig.dentist.role}`}
              className="w-full h-[450px] lg:h-[560px] object-cover"
              loading="lazy"
            />
          </div>
          <div className="absolute -bottom-6 -right-4 sm:right-8 bg-white rounded-2xl shadow-xl px-6 py-4">
            <p className="font-serif text-lg font-semibold text-navy-900">{clinicConfig.dentist.name}</p>
            <p className="text-xs text-sage-600 font-medium tracking-wide">{clinicConfig.dentist.role}</p>
          </div>
        </div>
        <div>
          <p className="text-xs sm:text-sm tracking-[0.2em] uppercase text-sage-600 font-semibold mb-4">
            Meet the Dentist
          </p>
          <h2 className="font-serif text-heading font-semibold text-navy-900 mb-6">
            {clinicConfig.dentist.name}
          </h2>
          <p className="text-navy-600 text-base leading-relaxed mb-5">
            {clinicConfig.dentist.bio}
          </p>
          <div className="bg-ivory-100 rounded-2xl p-6 border-l-4 border-sage-500 mb-6">
            <p className="font-serif text-lg italic text-navy-700 leading-relaxed">
              "{clinicConfig.dentist.philosophy}"
            </p>
          </div>
          <div className="mb-8">
            <h3 className="text-sm font-semibold text-navy-900 mb-3">Areas of interest</h3>
            <div className="flex flex-wrap gap-2">
              {clinicConfig.dentist.interests.map((interest) => (
                <span key={interest} className="px-4 py-1.5 text-xs font-medium text-navy-700 bg-ivory-200 rounded-full">
                  {interest}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function PatientFirst() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 px-5 sm:px-8 lg:px-12 bg-navy-900 text-white">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-5xl mx-auto`}>
        <SectionHeading
          eyebrow="Patient-First Approach"
          title="Why patients choose us"
          subtitle="It's the small things that make the biggest difference."
        />
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-4">
          {whyChoose.map((item, i) => (
            <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-navy-800/50 border border-navy-700">
              <div className="w-7 h-7 rounded-full bg-sage-500/20 flex items-center justify-center shrink-0 mt-0.5">
                <span className="text-sage-300 text-xs font-semibold">{i + 1}</span>
              </div>
              <p className="text-sm text-ivory-200/80 leading-relaxed">{item}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ClinicEnvironment() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto`}>
        <SectionHeading
          eyebrow="Clinic Environment"
          title="A space designed for calm"
          subtitle="Every detail of our clinic is considered — from lighting to layout — to make your visit feel comfortable."
        />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-14">
          {clinicConfig.images.clinicInterior.map((img, i) => (
            <div
              key={i}
              className={`rounded-2xl overflow-hidden shadow-lg ${
                i === 0 ? 'col-span-2 row-span-2' : ''
              }`}
            >
              <img
                src={img}
                alt={`Clinic interior ${i + 1}`}
                className={`w-full object-cover ${i === 0 ? 'h-full min-h-[300px]' : 'h-48'}`}
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function About() {
  return (
    <div className="page-enter">
      <PageHero />
      <Philosophy />
      <MeetDentist />
      <PatientFirst />
      <ClinicEnvironment />
      <CTASection />
    </div>
  );
}
