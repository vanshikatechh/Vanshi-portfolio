import { clinicConfig } from '@/config/clinic';
import { useReveal } from '@/hooks/useReveal';
import SectionHeading from '@/components/SectionHeading';
import CTASection from '@/components/CTASection';
import { Heart, Clock, MessageSquareText, UserRound } from 'lucide-react';

const benefits = [
  { icon: Heart, title: 'Calm environment', text: 'A quiet, welcoming space designed to ease anxiety from the moment you walk in. Soft lighting, comfortable seating, and no clinical feel.' },
  { icon: MessageSquareText, title: 'Clear treatment explanations', text: 'We talk through every option in plain language, show you what to expect, and answer every question — no jargon, no pressure.' },
  { icon: Clock, title: 'Comfort-first appointments', text: 'Generous appointment times mean we never rush. We move at your pace and check in with you at every stage of treatment.' },
  { icon: UserRound, title: 'Personalised care', text: 'Every treatment plan is built around your goals, your comfort, and your lifestyle. No two smiles are the same — no two plans should be either.' },
];

const steps = [
  { title: 'Before your visit', text: 'We send you everything you need — directions, parking details, and a short form so we can prepare for your appointment.' },
  { title: 'Your first appointment', text: 'We take time to understand your history, listen to your concerns, and carry out a thorough examination at a comfortable pace.' },
  { title: 'Your treatment plan', text: 'We explain our findings in plain language and recommend a clear, step-by-step plan. You decide when and how to proceed.' },
  { title: 'Ongoing care', text: 'After treatment, we stay in touch — checking in on your progress and providing guidance whenever you need it.' },
];

function PageHero() {
  return (
    <section className="pt-32 pb-16 px-5 sm:px-8 lg:px-12 bg-ivory-100">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-xs sm:text-sm tracking-[0.25em] uppercase text-sage-600 font-semibold mb-4">
          Patient Experience
        </p>
        <h1 className="font-serif text-display font-semibold text-navy-900 mb-5">
          Dental care should feel different.
        </h1>
        <p className="text-navy-600 text-lg leading-relaxed">
          From the atmosphere to the way we explain treatment, everything is designed to make your visit feel calm, clear, and unhurried.
        </p>
      </div>
    </section>
  );
}

function Benefits() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-7xl mx-auto`}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-14">
          <div>
            <SectionHeading
              eyebrow="What to Expect"
              title="Care that puts you at ease"
              subtitle="Four things that make the experience different." center={false}
            />
            <div className="space-y-6 mt-8">
              {benefits.map((b) => (
                <div key={b.title} className="flex gap-4">
                  <div className="w-11 h-11 rounded-full bg-sage-100 flex items-center justify-center shrink-0">
                    <b.icon className="w-5 h-5 text-sage-600" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-navy-900 mb-1">{b.title}</h3>
                    <p className="text-sm text-navy-600 leading-relaxed">{b.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img
              src={clinicConfig.images.clinicInterior[1]}
              alt="Clinic treatment room"
              className="rounded-2xl h-72 w-full object-cover shadow-lg"
              loading="lazy"
            />
            <img
              src={clinicConfig.images.clinicInterior[2]}
              alt="Clinic waiting area"
              className="rounded-2xl h-72 w-full object-cover shadow-lg mt-8"
              loading="lazy"
            />
            <img
              src={clinicConfig.images.clinicInterior[3]}
              alt="Clinic interior detail"
              className="rounded-2xl h-72 w-full object-cover shadow-lg -mt-4"
              loading="lazy"
            />
            <img
              src={clinicConfig.images.clinicInterior[0]}
              alt="Modern dental clinic"
              className="rounded-2xl h-72 w-full object-cover shadow-lg mt-4"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function Journey() {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  return (
    <section className="py-20 sm:py-28 px-5 sm:px-8 lg:px-12 bg-ivory-100">
      <div ref={ref} className={`reveal ${revealed ? 'revealed' : ''} max-w-5xl mx-auto`}>
        <SectionHeading
          eyebrow="Your Visit, Step by Step"
          title="What your visit looks like"
          subtitle="No surprises. Here's exactly what to expect from your first contact to ongoing care."
        />
        <div className="mt-14 space-y-8">
          {steps.map((s, i) => (
            <div key={i} className="flex gap-6 items-start">
              <div className="flex flex-col items-center shrink-0">
                <div className="w-12 h-12 rounded-full bg-navy-900 text-white flex items-center justify-center font-serif text-lg font-semibold">
                  {i + 1}
                </div>
                {i < steps.length - 1 && <div className="w-px h-16 bg-navy-200 mt-3" />}
              </div>
              <div className="pt-2">
                <h3 className="font-serif text-xl font-semibold text-navy-900 mb-2">{s.title}</h3>
                <p className="text-sm text-navy-600 leading-relaxed max-w-lg">{s.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function PatientExperience() {
  return (
    <div className="page-enter">
      <PageHero />
      <Benefits />
      <Journey />
      <CTASection
        title="Experience the difference for yourself."
        subtitle="Book a consultation and see how calm, modern dental care can feel."
      />
    </div>
  );
}
