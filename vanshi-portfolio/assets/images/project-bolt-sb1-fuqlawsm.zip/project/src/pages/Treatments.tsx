import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, MessageCircle } from 'lucide-react';
import { clinicConfig } from '@/config/clinic';
import { whatsappLink } from '@/lib/whatsapp';
import { useReveal } from '@/hooks/useReveal';
import SectionHeading from '@/components/SectionHeading';
import CTASection from '@/components/CTASection';

function PageHero() {
  return (
    <section className="pt-32 pb-16 px-5 sm:px-8 lg:px-12 bg-ivory-100">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-xs sm:text-sm tracking-[0.25em] uppercase text-sage-600 font-semibold mb-4">
          Our Treatments
        </p>
        <h1 className="font-serif text-display font-semibold text-navy-900 mb-5">
          Treatments tailored to you
        </h1>
        <p className="text-navy-600 text-lg leading-relaxed">
          Explore our range of dental treatments. Every plan is personalised — book a consultation to find out which option is right for your smile.
        </p>
      </div>
    </section>
  );
}

function TreatmentCard({ treatment, index }: { treatment: typeof clinicConfig.treatments[0]; index: number }) {
  const { ref, revealed } = useReveal<HTMLDivElement>();
  const isEven = index % 2 === 0;

  return (
    <div
      ref={ref}
      id={treatment.slug}
      className={`reveal ${revealed ? 'revealed' : ''} scroll-mt-24 grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
        isEven ? '' : 'lg:[direction:rtl]'
      }`}
    >
      <div className={`relative ${isEven ? '' : 'lg:[direction:ltr]'}`}>
        <div className="rounded-[1.75rem] overflow-hidden shadow-xl">
          <img
            src={treatment.image}
            alt={treatment.name}
            className="w-full h-[320px] sm:h-[400px] object-cover"
            loading="lazy"
          />
        </div>
      </div>
      <div className={isEven ? '' : 'lg:[direction:ltr]'}>
        <span className="inline-block px-3 py-1 text-xs font-medium text-sage-700 bg-sage-50 rounded-full mb-4">
          {treatment.category}
        </span>
        <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-navy-900 mb-4">
          {treatment.name}
        </h2>
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-navy-900 mb-1.5">What it is</h3>
            <p className="text-sm text-navy-600 leading-relaxed">{treatment.whatItIs}</p>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-navy-900 mb-1.5">Who it may suit</h3>
            <p className="text-sm text-navy-600 leading-relaxed">{treatment.suitableFor}</p>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-navy-900 mb-1.5">The consultation</h3>
            <p className="text-sm text-navy-600 leading-relaxed">{treatment.consultationProcess}</p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 mt-6">
          <Link
            to="/contact"
            className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium text-white bg-navy-900 rounded-full hover:bg-sage-600 transition-all duration-300"
          >
            <Calendar className="w-4 h-4" />
            Book a Consultation
          </Link>
          <a
            href={whatsappLink(`Hi, I'd like to know more about ${treatment.name}.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium text-navy-700 border border-navy-200 rounded-full hover:bg-navy-900 hover:text-white hover:border-navy-900 transition-all duration-300"
          >
            <MessageCircle className="w-4 h-4" />
            Enquire on WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}

export default function Treatments() {
  useEffect(() => {
    if (window.location.hash) {
      const el = document.getElementById(window.location.hash.slice(1));
      if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }
  }, []);

  return (
    <div className="page-enter">
      <PageHero />
      <section className="py-16 sm:py-24 px-5 sm:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto space-y-20 sm:space-y-28">
          {clinicConfig.treatments.map((treatment, i) => (
            <TreatmentCard key={treatment.slug} treatment={treatment} index={i} />
          ))}
        </div>
      </section>
      <CTASection
        title="Not sure which treatment is right for you?"
        subtitle="Book a consultation and we'll help you understand your options — no pressure, no jargon."
      />
    </div>
  );
}
