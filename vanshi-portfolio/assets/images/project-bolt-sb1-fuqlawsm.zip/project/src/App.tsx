import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ScrollToTop from '@/components/ScrollToTop';
import FloatingCTA from '@/components/FloatingCTA';
import ExitIntentModal from '@/components/ExitIntentModal';
import Home from '@/pages/Home';
import Treatments from '@/pages/Treatments';
import BeforeAfter from '@/pages/BeforeAfter';
import About from '@/pages/About';
import PatientExperience from '@/pages/PatientExperience';
import Contact from '@/pages/Contact';
import { clinicConfig } from '@/config/clinic';

function LegalPage({ title, content }: { title: string; content: string[] }) {
  return (
    <div className="page-enter pt-32 pb-20 px-5 sm:px-8 lg:px-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="font-serif text-heading font-semibold text-navy-900 mb-8">{title}</h1>
        <div className="space-y-4">
          {content.map((p, i) => (
            <p key={i} className="text-navy-600 text-sm leading-relaxed">{p}</p>
          ))}
        </div>
        <p className="text-xs text-navy-400 mt-10">
          This website is a demonstration concept. Treatment suitability should be assessed by a qualified dental professional.
        </p>
      </div>
    </div>
  );
}

function Privacy() {
  return (
    <LegalPage
      title="Privacy Policy"
      content={[
        `${clinicConfig.name} respects your privacy and is committed to protecting your personal data. This policy explains how we collect, use, and store information you provide through this website.`,
        'We collect information you provide directly — such as your name, phone number, email address, and treatment preferences — when you submit an appointment request or contact us via WhatsApp or email.',
        'We use this information solely to respond to your enquiry, arrange appointments, and provide dental care. We do not share your personal data with third parties for marketing purposes.',
        'You may request access to, correction of, or deletion of your personal data at any time by contacting us using the details on our Contact page.',
        'This is a demonstration website. In a live deployment, this policy would be reviewed and tailored to comply with applicable data protection regulations.',
      ]}
    />
  );
}

function Terms() {
  return (
    <LegalPage
      title="Terms of Use"
      content={[
        `Welcome to the ${clinicConfig.name} website. By accessing this site, you agree to the following terms.`,
        'The information on this website is for general informational purposes only and does not constitute medical or dental advice. Treatment suitability should be assessed by a qualified dental professional following an in-person consultation.',
        'Before and after images shown on this website are for demonstration purposes. Results vary between patients and no specific outcome is guaranteed.',
        'Appointment requests submitted through this website are not confirmed bookings. We will contact you to confirm availability and schedule your consultation.',
        'This is a demonstration website. In a live deployment, these terms would be reviewed by legal counsel and tailored to the clinic\'s specific requirements.',
      ]}
    />
  );
}

function NotFound() {
  return (
    <div className="page-enter min-h-screen flex items-center justify-center px-5">
      <div className="text-center">
        <p className="font-serif text-7xl font-semibold text-navy-900 mb-4">404</p>
        <p className="text-navy-600 mb-8">The page you're looking for doesn't exist.</p>
        <a href="/" className="inline-flex items-center px-6 py-3 text-sm font-medium text-white bg-navy-900 rounded-full hover:bg-sage-600 transition-all">
          Back to Home
        </a>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/treatments" element={<Treatments />} />
          <Route path="/before-and-after" element={<BeforeAfter />} />
          <Route path="/about" element={<About />} />
          <Route path="/patient-experience" element={<PatientExperience />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <FloatingCTA />
      <ExitIntentModal />
    </BrowserRouter>
  );
}
