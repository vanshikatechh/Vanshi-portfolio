/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: '#fdfcfb',
          100: '#faf8f5',
          200: '#f5f1eb',
          300: '#ede7dc',
          400: '#e0d7c6',
        },
        navy: {
          50: '#f0f3f8',
          100: '#dce3ef',
          200: '#b8c7df',
          300: '#8aa1c9',
          400: '#5a7aaf',
          500: '#3a5e97',
          600: '#2d4a7d',
          700: '#243c64',
          800: '#1c2f4f',
          900: '#16243d',
          950: '#0f1828',
        },
        sage: {
          50: '#f4f7f5',
          100: '#e6ede9',
          200: '#cedbcf',
          300: '#a9c2ab',
          400: '#7fa383',
          500: '#5d8762',
          600: '#486b4d',
          700: '#3a563f',
          800: '#2f4533',
          900: '#26382b',
        },
        teal: {
          50: '#f0f7f7',
          100: '#d9eded',
          200: '#b3dada',
          300: '#82c2c2',
          400: '#54a3a3',
          500: '#3d8585',
          600: '#316a6a',
          700: '#285454',
          800: '#224545',
          900: '#1d3a3a',
        },
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display': ['clamp(2.5rem, 6vw, 5rem)', { lineHeight: '1.05', letterSpacing: '-0.02em' }],
        'heading': ['clamp(2rem, 4vw, 3.25rem)', { lineHeight: '1.1', letterSpacing: '-0.015em' }],
        'subheading': ['clamp(1.25rem, 2vw, 1.625rem)', { lineHeight: '1.3', letterSpacing: '-0.01em' }],
      },
      animation: {
        'fade-up': 'fadeUp 0.7s ease-out forwards',
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'float': 'float 6s ease-in-out infinite',
        'float-delayed': 'float 6s ease-in-out 2s infinite',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
};
